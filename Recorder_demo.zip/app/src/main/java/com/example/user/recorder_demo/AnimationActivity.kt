package com.example.user.recorder_demo

import android.content.Intent
import android.opengl.Visibility
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.animationactivity.*

class AnimationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.animationactivity)

        var user_name : String? = null
        var user_age : String? = null
        var user_gender : String? = null
        var user_alchol : String? = null


        //인텐트 값 받자
        if (intent.hasExtra("In_name") &&
            intent.hasExtra("In_age") &&
            intent.hasExtra("In_gender") &&
            intent.hasExtra("In_alchol") ) {

             user_name = intent.getStringExtra("In_name")
             user_age = intent.getStringExtra("In_age")
             user_gender = intent.getStringExtra("In_gender")
             user_alchol = intent.getStringExtra("In_alchol")



         //   Toast.makeText(this, user_age + user_alchol + user_gender + user_name, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "온전한 정보가 전달되지 않았습니다.", Toast.LENGTH_SHORT).show()
        }



        ///버튼 클릭으로 애니메이션 무빙무빙
        button_circle_animation.setOnClickListener {
            val icm = findViewById<ImageView>(R.id.image_circle_moving)
            val anim = AnimationUtils.loadAnimation(applicationContext, R.anim.moving)
            icm.startAnimation(anim)
            button_circle_animation.visibility = View.INVISIBLE
            button_next.visibility = View.VISIBLE
        }

        ///하나더 생긴 버튼으로 넘기자, 바로넘겨도되는데 애니메이션 끝날때 넘기는거모르겠음
        button_next.setOnClickListener {
            val resultIntent = Intent(this@AnimationActivity, VoiceRecorderActivity::class.java) // Intent객체 생성방법

            resultIntent.putExtra("In_name", user_name)
            resultIntent.putExtra("In_age", user_age)
            resultIntent.putExtra("In_gender", user_gender)
            resultIntent.putExtra("In_alchol", user_alchol)


            startActivity(resultIntent)
        }


    }
}
