package com.example.user.recorder_demo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

import java.io.File

class VoiceRecorderActivity_sample : AppCompatActivity() {
    //초기화 및 허가
    val VIDEO_REQUEST_CODE = 100
    private var permissionToRecordAccepted = false
    private var permissionToWriteAccepted = false
    private var permissionToCameraAccepted = false
    private var permissionToReadAccepted = false
    private var permissionToHardwareCameraAccepted = false



    private val permissions = arrayOf("android.permission.RECORD_AUDIO", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA"
    ,"android.permission.READ_EXTERNAL_STORAGE","android.hardware.camera2" )



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.videorecorder_sample)

        val requestCode = 200
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(permissions, requestCode)
        }


    }
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            200 -> {
                permissionToRecordAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED
                permissionToWriteAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED
                permissionToCameraAccepted = grantResults[2] == PackageManager.PERMISSION_GRANTED
                permissionToReadAccepted  = grantResults[3] == PackageManager.PERMISSION_GRANTED
                //permissionToHardwareCameraAccepted = grantResults[4] == PackageManager.PERMISSION_GRANTED

            }
        }
        if (!permissionToRecordAccepted) super@VoiceRecorderActivity_sample.finish()
        if (!permissionToWriteAccepted) super@VoiceRecorderActivity_sample.finish()
        if (!permissionToCameraAccepted) super@VoiceRecorderActivity_sample.finish()
        if (!permissionToReadAccepted ) super@VoiceRecorderActivity_sample.finish()
        //if (!permissionToHardwareCameraAccepted) super@VoiceRecorderActivity_sample.finish()

    }
    fun captureVideo()
    {
        val camera_intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
        val video_file = getFilepath()
        val video_uri =  Uri.fromFile(video_file)
        camera_intent.putExtra(MediaStore.EXTRA_OUTPUT,video_uri)
        camera_intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,1)


        startActivityForResult(camera_intent, VIDEO_REQUEST_CODE)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == VIDEO_REQUEST_CODE)
        {
            if(resultCode == RESULT_OK)
            {
                Toast.makeText(this, "Video Susseffuly", Toast.LENGTH_SHORT).show()
            }
            else
            {
                Toast.makeText(this, " fail", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getFilepath() : File
    {
        val folder = File("sdcard/video_app")
        if(folder.exists())
        {
            folder.mkdir()

        }

        return File(folder, "sample_video.mp4")
    }


}
