package com.example.user.java_sample;


import java.io.IOException;

import android.app.ActionBar;
import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.Camera;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class AndroidCamera extends Activity implements SurfaceHolder.Callback{

    Camera camera;
    SurfaceView surfaceView;
    SurfaceHolder surfaceHolder;
    boolean previewing = false;
    LayoutInflater controlInflater = null;

    //사각형 위치
    private float RectLeft, RectTop,RectRight,RectBottom ;
    int  deviceHeight,deviceWidth;

    String stringPath = "/sdcard/samplevideo.3gp";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //서페이스
        getWindow().setFormat(PixelFormat.UNKNOWN);
        surfaceView = (SurfaceView)findViewById(R.id.surfaceview);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback((SurfaceHolder.Callback) this);
        surfaceView.setSecure(true);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        surfaceHolder.setFormat(PixelFormat.TRANSLUCENT);
        surfaceView.setZOrderMediaOverlay(true);
        deviceWidth=getScreenWidth();
        deviceHeight=getScreenHeight();



/*
        //투명 서페이스
        transparentView = (SurfaceView)findViewById(R.id.transparentView2);
        holderTransparent = transparentView.getHolder();
        holderTransparent.addCallback((SurfaceHolder.Callback) this);
        holderTransparent.setFormat(PixelFormat.TRANSLUCENT);
        transparentView.setZOrderMediaOverlay(true);
        //getting the device heigth and width
        deviceWidth=getScreenWidth();
        deviceHeight=getScreenHeight();
*/
        //surface에 버튼 추가
        controlInflater = LayoutInflater.from(getBaseContext());
        View viewControl = controlInflater.inflate(R.layout.control, null);
        ActionBar.LayoutParams layoutParamsControl = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT);
        ActionBar.LayoutParams layoutParamsControl2 = new ActionBar.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT);
        this.addContentView(viewControl, layoutParamsControl );


        //시작과 동시에 애니메이션
        final Button Start_button = (Button)findViewById(R.id.button_circle_animation);
        final Button Next_button = (Button)findViewById(R.id.button_next);
        Start_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //애니메이션 부분
                ImageView icm = (ImageView)findViewById(R.id.image_circle_moving) ;
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.moving);
                icm.startAnimation(anim);
                Start_button.setVisibility(View.INVISIBLE);
                Next_button.setVisibility(View.VISIBLE);

                //촬영시작부분

            }
        });
        //다음으로
        /*button_next.setOnClickListener {
            val resultIntent = Intent(this@AnimationActivity, VoiceRecorderActivity::class.java) // Intent객체 생성방법

            resultIntent.putExtra("In_name", user_name)
            resultIntent.putExtra("In_age", user_age)
            resultIntent.putExtra("In_gender", user_gender)
            resultIntent.putExtra("In_alchol", user_alchol)


            startActivity(resultIntent)
        }*/



    }

    private void Draw()
    {
        Canvas canvas = surfaceHolder.lockCanvas(null);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.GREEN);
        paint.setStrokeWidth(5);

        RectLeft = deviceWidth/2 + 400;
        RectRight = deviceWidth/2 - 400;
        RectTop = deviceHeight/2 + 200;
        RectBottom = deviceHeight/2 - 600;
        Rect rec=new Rect((int) RectLeft,(int)RectTop,(int)RectRight,(int)RectBottom);
        canvas.drawRect(rec,paint);
        surfaceHolder.unlockCanvasAndPost(canvas);
    }
    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
      if(previewing)
      {
          camera.stopPreview();
          previewing = false;
      }

      if(camera != null)
      {
          try{
              camera.setPreviewDisplay(surfaceHolder);
              camera.startPreview();
              previewing = true;
          }
          catch (IOException e)
          {
              e.printStackTrace();
          }
      }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        camera = Camera.open();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        camera.stopPreview();
        camera.release(); //for release a camera
        camera = null;
        previewing = false;
    }
}