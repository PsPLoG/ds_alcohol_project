package com.example.user.java_sample;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.VideoView;


public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback {
    //global variables
    SurfaceView  cameraView,transparentView;
    SurfaceHolder holder,holderTransparent;
    Camera camera;
    private float RectLeft, RectTop,RectRight,RectBottom ;
    int  deviceHeight,deviceWidth;
    static final int REQUEST_VIDEO_CAPTURE = 1;
    VideoView result_video;

    boolean previewing = false;


    private boolean permissionToRecordAccepted = false;
    private boolean permissionToWriteAccepted = false;
    private boolean permissionToCameraAccepted = false;
    private boolean permissionToReadAccepted = false;

    private String[] permissions = {"android.permission.RECORD_AUDIO", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA"
            ,"android.permission.READ_EXTERNAL_STORAGE","android.hardware.camera2"};




    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button click = (Button)findViewById(R.id.videorec);
        result_video = (VideoView)findViewById(R.id.videoView);


        //처음에 권한얻어오려고 확인
        int requestCode = 200;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(permissions, requestCode);
        }



    cameraView = (SurfaceView)findViewById(R.id.CameraView);
        holder = cameraView.getHolder();
        holder.addCallback((SurfaceHolder.Callback) this);
        //holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        cameraView.setSecure(true);
        // Create second surface with another holder (holderTransparent)
        transparentView = (SurfaceView)findViewById(R.id.TransparentView);
        holderTransparent = transparentView.getHolder();
        holderTransparent.addCallback((SurfaceHolder.Callback) this);
        holderTransparent.setFormat(PixelFormat.TRANSLUCENT);
        transparentView.setZOrderMediaOverlay(true);
        //getting the device heigth and width
        deviceWidth=getScreenWidth();
        deviceHeight=getScreenHeight();
    }

    public void dispatchTakeVideoIntent(View v){
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if(takeVideoIntent.resolveActivity(getPackageManager()) != null)
        {
            startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK)
        {
            Uri videoUri = data.getData();
            result_video.setVideoURI(videoUri);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch(requestCode)
        {
            case 200 :{
                permissionToRecordAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                permissionToWriteAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                permissionToCameraAccepted = grantResults[2] == PackageManager.PERMISSION_GRANTED;
                permissionToReadAccepted  = grantResults[3] == PackageManager.PERMISSION_GRANTED;
                //permissionToHardwareCameraAccepted = grantResults[4] == PackageManager.PERMISSION_GRANTED

            }break;
        }
        if (!permissionToRecordAccepted) finish();
        if (!permissionToWriteAccepted) finish();
        if (!permissionToCameraAccepted) finish();
        if (!permissionToReadAccepted ) finish();
        //if (!permissionToHardwareCameraAccepted) super@VoiceRecorderActivity_sample.finish()

    }


    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    private void Draw()
    {
        Canvas canvas = holderTransparent.lockCanvas(null);

        Paint  paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.GREEN);
        paint.setStrokeWidth(5);

        RectLeft = deviceWidth/2 + 400;
        RectRight = deviceWidth/2 - 400;
        RectTop = deviceHeight/2 + 200;
        RectBottom = deviceHeight/2 - 600;
        Rect rec=new Rect((int) RectLeft,(int)RectTop,(int)RectRight,(int)RectBottom);
        canvas.drawRect(rec,paint);
        holderTransparent.unlockCanvasAndPost(canvas);
    }
    @Override

    public void surfaceCreated(SurfaceHolder holder) {
       camera = Camera.open();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

        refreshCamera(); //call method for refress camera
    }

    public void refreshCamera() {

        if (holder.getSurface() == null) {
            return;
        }
        try {
            camera.stopPreview();
        }

        catch (Exception e) {
        }

        try {
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        }

        catch (Exception e) {
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        camera.stopPreview();
        camera.release(); //for release a camera
        camera = null;
        previewing = false;
    }



}